/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ramdhoni.aplikasi;

/**
 *
 * @author USER
 */
public class loginsession {
   
    public static int UID; // Global User ID
    public static String HAK_AKSES; // Global Usertype
    public static String USERNAME; // Global Nickname
    public static String NAMA_DEPAN; // Global Usertype
    public static String NAMA_BELAKANG; // Global Nickname
    public static String PASSWORD; // Global Usertype
    public static int NIS; // Global Usertype
    public static String ALAMAT; // Global Nickname
    public static String TANGGAL_LAHIR; // Global UsertypE
    public static boolean isLoggedIn = false; // Check is User is logged in.
    
}
