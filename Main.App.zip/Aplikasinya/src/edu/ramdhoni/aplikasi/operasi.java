 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ramdhoni.aplikasi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class operasi {
      public static boolean isLogin(String username,String password,  JFrame frame){
        try{
            Connection conn = new koneksi().connect();
            String mySqlQuery = 
                    "SELECT id_siswa, nama_depan, nama_belakang, username, password, nis, tanggal_lahir, alamat FROM tb_siswa WHERE username = '"+
                    username+
                    "' AND password = '"+
                    password+"'";
            PreparedStatement preparedStatement = conn.prepareStatement(mySqlQuery);
            ResultSet resultSet = preparedStatement.executeQuery();
            
            while(resultSet.next()){
                loginsession.UID = resultSet.getInt("id_siswa");
                loginsession.NAMA_DEPAN = resultSet.getString("nama_depan");
                loginsession.NAMA_BELAKANG = resultSet.getString("nama_belakang");
                loginsession.USERNAME = resultSet.getString("username");
                loginsession.PASSWORD = resultSet. getString("password");
                loginsession.NIS = resultSet.getInt("nis");
                loginsession.TANGGAL_LAHIR = resultSet.getString("tanggal_lahir");
                loginsession.ALAMAT = resultSet.getString("alamat");
                return true;
            }
            
        }catch (Exception exception){
            JOptionPane.showMessageDialog(frame, "Anda belum tersambung dengan Server kami " + exception.getMessage());
        }
        
        return false;
    }


    
      
}

