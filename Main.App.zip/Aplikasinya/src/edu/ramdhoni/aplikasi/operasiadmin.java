/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.ramdhoni.aplikasi;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class operasiadmin {
    public static boolean isLogin(String refferal, JFrame frame){
        try{
            Connection conn = new koneksi().connect();
            String mySqlQuery = 
                    "SELECT id_admin,  nama_depan, nama_belakang, username, password, kode_refferal, tgl_lahir, alamat FROM tb_admin WHERE kode_refferal = '"+
                   refferal+"'";
            PreparedStatement preparedStatement = conn.prepareStatement(mySqlQuery);
            ResultSet resultSet = preparedStatement.executeQuery();
    while(resultSet.next()){
                loginsessionadmin.UID = resultSet.getInt("id_admin");
                loginsessionadmin.NAMA_DEPAN = resultSet.getString("nama_depan");
                loginsessionadmin.NAMA_BELAKANG = resultSet.getString("nama_belakang");
                loginsessionadmin.USERNAME = resultSet.getString("username");
                loginsessionadmin.PASSWORD = resultSet. getString("password");
                loginsessionadmin.REFFERAL = resultSet.getString("kode_refferal");
                loginsessionadmin.TANGGAL_LAHIR = resultSet.getString("tgl_lahir");
                loginsessionadmin.ALAMAT = resultSet.getString("alamat");
                return true;
}
}catch (Exception exception){
            JOptionPane.showMessageDialog(frame, "Anda belum tersambung dengan Server kami " + exception.getMessage());
        }
        
        return false;
     
    } public static boolean isLogin2(String username, String password, JFrame frame){
        try{
            Connection conn = new koneksi().connect();
            String mySqlQuery = 
                    "SELECT id_admin,  nama_depan, nama_belakang, username, password, kode_refferal, tgl_lahir, alamat FROM tb_admin WHERE username = '"+
                   username+"' AND password = '"+
                   password+"'";
            PreparedStatement preparedStatement = conn.prepareStatement(mySqlQuery);
            ResultSet resultSet = preparedStatement.executeQuery();
    while(resultSet.next()){
                loginsessionadmin.UID = resultSet.getInt("id_admin");
                loginsessionadmin.NAMA_DEPAN = resultSet.getString("nama_depan");
                loginsessionadmin.NAMA_BELAKANG = resultSet.getString("nama_belakang");
                loginsessionadmin.USERNAME = resultSet.getString("username");
                loginsessionadmin.PASSWORD = resultSet. getString("password");
                loginsessionadmin.REFFERAL = resultSet.getString("kode_refferal");
                loginsessionadmin.TANGGAL_LAHIR = resultSet.getString("tgl_lahir");
                loginsessionadmin.ALAMAT = resultSet.getString("alamat");
                return true;
}
}catch (Exception exception){
            JOptionPane.showMessageDialog(frame, "Anda belum tersambung dengan Server kami " + exception.getMessage());
        }
        
        return false;
}
}
